import React, { Component } from 'react';
import { Redirect, Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import axios from 'axios';
import _ from 'lodash';

import config from '../config';
import { fetchPrice, setWallet, errorAlert } from '../actions/index.js';

import CoinInput from './CoinInput';
import WalletAddress from './WalletAddress';


class ExchangeWidget extends Component {
	constructor(props) {
		super();
		
		this.state = {
			orderPlaced: false,
			loading: false,
	  	};
	  	  	 	
	  	this.placeOrder = this.placeOrder.bind(this);
	  	this.placeOrderOnBackend = this.placeOrderOnBackend.bind(this);
	  	this.updatePrices = this.updatePrices.bind(this);
	}

	componentDidMount() {
		this.updatePrices();
	}

	componentWillUnmount() {
		clearTimeout(this.timeout);
	}

	updatePrices() {
		this.props.fetchPrice({pair: `${this.props.selectedCoin.receive}${this.props.selectedCoin.deposit}`, lastEdited: 'deposit', amount: this.props.amounts.deposit});

		this.timeout = setTimeout(() => {
			this.updatePrices(true);
		}, config.PRICE_FETCH_INTERVAL);
	}

	placeOrder() {
		this.setState({loading: true});

		if (this.props.amounts.lastEdited == 'receive')
			this.placeOrderOnBackend(this.props.amounts.receive);

	    axios.get(`${config.API_BASE_URL}/price/${this.props.selectedCoin.receive}${this.props.selectedCoin.deposit}/latest/`)
	        .then(response => {
	        	if (!response.data.length) return;

				let price = response.data[0].ticker.ask,
					quote = this.props.amounts.deposit,
					amount = parseFloat(quote) / price;

				this.placeOrderOnBackend(amount.toFixed(8));
	        }).catch(error => {
	        	console.log(error);
	        	this.props.errorAlert({message: 'Something went wrong. Please try again later', show: true, type: 'PLACE_ORDER'});
	        });
	}

	placeOrderOnBackend(amount) {
		axios({
			method: 'post',
			contentType : 'application/json',
			url: `${config.API_BASE_URL}/orders/`,
			data: {
				"amount_base": amount, 
				"is_default_rule": true,
				"pair": {
					"name": `${this.props.selectedCoin.receive}${this.props.selectedCoin.deposit}`
				},
				"withdraw_address": {
					"address": this.props.wallet.address,
					"name": ""
				}
			}
		})
		.then(response => {
			this.setState({orderRef: response.data.unique_reference, orderPlaced: true, loading: false});

			ga('send', 'event', 'Order', 'place order', response.data.unique_reference);
		})
		.catch(error => {
			console.log(error.response)

			let message = (error.response && error.response.data.non_field_errors && error.response.data.non_field_errors.length ? error.response.data.non_field_errors[0] : 'Something went wrong. Please try again later.');
			this.props.errorAlert({message: message, show: true, type: 'PLACE_ORDER'});
			this.setState({orderPlaced: false, loading: false});
		});
	}

	componentWillReceiveProps(nextProps) {
		if (this.props.wallet.show && nextProps.error.type == 'INVALID_AMOUNT' && nextProps.error.show != false)
			this.props.setWallet({address: '', valid: false, show: false});
	}

	render() {
		if (this.state.orderPlaced)
			return <Redirect to={`/order/${this.state.orderRef}`} />

		return (
			<div className="col-xs-12">
				<div id="exchange-widget">
					<div className="col-xs-12 col-sm-6">
						<CoinInput type="deposit" />
					</div>

					<div className="col-xs-12 col-sm-6">
						<CoinInput type="receive" />
					</div>

					<WalletAddress />

					<div className="col-xs-12 text-center">
						{!this.props.wallet.show ? (
							<button className="btn btn-block btn-themed proceed" onClick={() => this.props.setWallet({address: '', valid: false, show: true})} disabled={this.props.error.show && this.props.error.type == 'INVALID_AMOUNT' ? 'disabled' : null}>
								Get Started !
							</button>
						) : (
							<button className="btn btn-block btn-themed proceed" onClick={this.placeOrder} disabled={(this.props.wallet.valid && !this.state.loading) ? null : 'disabled'}>
								Confirm & Place Order
								{this.state.loading ? <i className="fa fa-spinner fa-spin" style={{marginLeft: "10px"}}></i> : null}
							</button>
						)}
					</div>
				</div>
			</div>
		);
	}
}


function mapStateToProps(state) {
	return {
		selectedCoin: state.selectedCoin,
		amounts: state.amounts,
		error: state.error,
		wallet: state.wallet,
		price: state.price,
	}
}

function mapDispatchToProps(dispatch) {
	return bindActionCreators({
		fetchPrice: fetchPrice,
		setWallet: setWallet,
		errorAlert: errorAlert,
	}, dispatch)
}

export default connect(mapStateToProps, mapDispatchToProps)(ExchangeWidget);
