import React from 'react';

const Footer = () => (
	<footer>
		<div className="container">
		  <p className="text-muted">&copy; Nexchange Open Client BETA</p>
		</div>
	</footer>
);

export default Footer;
